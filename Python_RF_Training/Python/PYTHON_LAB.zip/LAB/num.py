#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      MohanKumarP
#
# Created:     19/12/2015
# Copyright:   (c) MohanKumarP 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def square(x=0):
    """Computes square of a number."""
    return x * x

def cube(x):
    """Computes cube of a number."""
    import os
    return x * x * x

def main():
    pass

if __name__ == '__main__':
    main()
